# SnAIke_VS_TheWorld

This is the GitHub REPO for our project for our Machine Learning class with Dr. B 

Creators:
Wyatt Ferrics
Spencer Rhoden
Payne Moser

Use this repo to implement your own snAIke, just follow the process document. All of the python code you need is in the "py" folder.

We are using and implementing Patrick Loeber's code, you can find his GitHub here: https://github.com/patrickloeber/snake-ai-pytorch
