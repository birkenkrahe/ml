https://towardsdatascience.com/primer-on-developing-reproducible-neural-networks-in-jupyter-notebook-2f88d23b7c8d

https://jupyter.org/install

https://www.youtube.com/watch?v=L8ypSXwyBds

https://github.com/carlosgoe/snake-rl/blob/main/snake_game.py

https://www.edureka.co/blog/snake-game-with-pygame/

